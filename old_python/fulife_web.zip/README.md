# FULIFE Game

A life simulation game where you build your career and life.

## Play the Game

You can play the game directly in your browser by visiting the GitHub Pages URL.

## Controls

- WASD or Arrow keys: Move your character
- E: Interact with NPCs and objects
- I: Open inventory
